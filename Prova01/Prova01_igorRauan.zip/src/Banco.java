import java.util.ArrayList;
public class Banco {
    ArrayList<Cliente> clientes = new ArrayList<Cliente>();
    ArrayList<Conta> contas = new ArrayList<Conta>();


    public static void main(String[] args) throws Exception {

        Pessoa cliente1 = new Cliente("Igor", "00000", "11111", "000111", 20);
        Pessoa cliente2 = new Cliente("Rauan", "22222", "11111", "222111", 20);
    }
}
