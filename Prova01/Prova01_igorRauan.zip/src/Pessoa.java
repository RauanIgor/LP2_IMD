public class Pessoa {
    String nome;
    String cpf;
    String rg;
    String identificador;
    int idade;

    public Pessoa(String nome, String cpf, String rg, int idade) {
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.idade = idade;
    }
}
