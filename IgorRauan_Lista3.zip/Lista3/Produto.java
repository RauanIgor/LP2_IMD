interface Produto {
    public String obterNome();
    public double obterPreco();
    public double calcularDesconto(double desconto);

}
